Project contains 3 files
1)Randomizer : generates random integer which is less than 1000
2)Prime : Checks if the number is prime or not
3)DistributedQueueClient : create java queue which holds integers. Get random numbers from randomizer and add it to queue.  
Read one by one element from queue and check if the number is prime using Prime.java
Print if the number is prime or not 


1)What is your design and implementation?
My design is, i have implemented 3 different classes, prime class for checking the prime number, 
randomizer class for creating the random number, distributedqueue for implementing the main 
program using theother two classes.

2) Sample Output

10 is not a prime number
29 is a prime number
40 is not a prime number

3)FutureWork
We can ask the user for how many random number can be printed.
We can also use aggregation.